import telebot
import sqlite3
import logging
import json

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
bot = telebot.TeleBot('токен свой ставь')

# Команда /start
@bot.message_handler(commands=['start'])
def start(message):
    response = (
        '⛔Команды:\n\n'
        '/info [id] - Узнать об аккаунте.\n'
        '/connect [id] [token] - Привязать аккаунт.\n'
        '/unlink - Отвязать аккаунт.\n'
        '/recovery [main id] [new id] [new token] - Восстановить аккаунт.\n\n'
    )
    bot.reply_to(message, response)

# Команда /profile
@bot.message_handler(commands=['profile'])
def handle_profile(message):
    user_id = message.from_user.id
    try:
        with sqlite3.connect('Database/Files/player.sqlite') as db:
            cursor = db.cursor()
            cursor.execute("SELECT Data FROM main WHERE ID = ?", (user_id,))
            account = cursor.fetchone()
            
            if account:
                data = json.loads(account[0])  # Декодируем JSON из поля Data
                profile_info = (
                    f"🤠 Статистика аккаунта {data['Name']}:\n\n"
                    f"🆔 ID: {data['ID'][1]}\n"
                    f"💎 Гемы: {data['Gems']}\n"
                    f"💸 Монеты: {data['Coins']}\n"
                    f"🏆 Трофеи: {data['Trophies']}\n"
                    f"🏅 Рекорд трофеев: {data['HighestTrophies']}\n"
                    f"⭐ Уровень: {data['Level']} (опыт: {data['Experience']})\n"
                    f"🌍 Регион: {data['Region']}\n"
                )
                bot.send_message(user_id, profile_info)
            else:
                bot.send_message(user_id, "❌ Вы не привязали аккаунт. Используйте команду /connect.")
    except Exception as e:
        logging.error(f"Ошибка в команде /profile: {e}")
        bot.send_message(user_id, f"❌ Произошла ошибка: {str(e)}")

# Команда /info
@bot.message_handler(commands=['info'])
def info_command(message):
    args = message.text.split()
    if len(args) != 2:
        bot.send_message(message.chat.id, "❌ Используйте команду в формате: /info [ID]")
        return
    try:
        player_id = int(args[1])
        with sqlite3.connect('Database/Files/player.sqlite') as db:
            cursor = db.cursor()
            cursor.execute("SELECT Data FROM main WHERE ID = ?", (player_id,))
            account = cursor.fetchone()
            
            if account:
                data = json.loads(account[0])  # Декодируем JSON из поля Data
                info = (
                    f"🤠 Информация об аккаунте {data['Name']}:\n\n"
                    f"🆔 ID: {data['ID'][1]}\n"
                    f"💎 Гемы: {data['Gems']}\n"
                    f"💸 Монеты: {data['Coins']}\n"
                    f"🏆 Трофеи: {data['Trophies']}\n"
                    f"🏅 Рекорд трофеев: {data['HighestTrophies']}\n"
                    f"⭐ Уровень: {data['Level']}\n"
                    f"🌍 Регион: {data['Region']}\n"
                )
                bot.send_message(message.chat.id, info)
            else:
                bot.send_message(message.chat.id, "❌ Аккаунт с указанным ID не найден.")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Неверный формат ID. Убедитесь, что вы вводите число.")
    except Exception as e:
        logging.error(f"Ошибка в команде /info: {e}")
        bot.send_message(message.chat.id, f"❌ Произошла ошибка: {str(e)}")

# Команда /connect
@bot.message_handler(commands=['connect'])
def connect_command(message):
    try:
        parts = message.text.split()
        if len(parts) != 3:
            bot.send_message(message.chat.id, "❌ Используйте команду: /connect [ID] [Token]")
            return

        player_id = int(parts[1])
        token = parts[2]
        user_id = message.from_user.id

        with sqlite3.connect('Database/Files/player.sqlite') as db:
            cursor = db.cursor()
            cursor.execute("SELECT Data FROM main WHERE ID = ?", (player_id,))
            account = cursor.fetchone()

            if account:
                data = json.loads(account[0])  # Декодируем JSON из поля Data
                if data["Token"] == token:
                    data["TelegramID"] = user_id  # Привязываем Telegram ID
                    cursor.execute(
                        "UPDATE main SET Data = ? WHERE ID = ?",
                        (json.dumps(data, ensure_ascii=False), player_id)
                    )
                    db.commit()
                    bot.send_message(
                        message.chat.id,
                        f"✅ Аккаунт {data['Name']} успешно привязан!\n🆔 ID: {player_id}"
                    )
                else:
                    bot.send_message(message.chat.id, "❌ Токен не совпадает!")
            else:
                bot.send_message(message.chat.id, "❌ Аккаунт с указанным ID не найден.")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Неверный формат ID.")
    except Exception as e:
        logging.error(f"Ошибка в команде /connect: {e}")
        bot.send_message(message.chat.id, f"❌ Произошла ошибка: {str(e)}")

# Команда /unlink
@bot.message_handler(commands=['unlink'])
def unlink_command(message):
    user_id = message.from_user.id
    try:
        with sqlite3.connect('Database/Files/player.sqlite') as db:
            cursor = db.cursor()
            cursor.execute("SELECT Data FROM main WHERE ID = ?", (user_id,))
            account = cursor.fetchone()

            if account:
                data = json.loads(account[0])  # Декодируем JSON из поля Data
                data.pop("TelegramID", None)  # Удаляем привязку
                cursor.execute(
                    "UPDATE main SET Data = ? WHERE ID = ?",
                    (json.dumps(data, ensure_ascii=False), user_id)
                )
                db.commit()
                bot.send_message(message.chat.id, "✅ Аккаунт успешно отвязан.")
            else:
                bot.send_message(message.chat.id, "❌ Вы не привязали аккаунт.")
    except Exception as e:
        logging.error(f"Ошибка в команде /unlink: {e}")
        bot.send_message(message.chat.id, f"❌ Произошла ошибка: {str(e)}")

# Команда /recovery
@bot.message_handler(commands=['recovery'])
def recovery_command(message):
    args = message.text.split()
    if len(args) != 4:
        bot.send_message(message.chat.id, "❌ Используйте команду: /recovery <ID_основного_аккаунта> <ID_нового_аккаунта> <токен_нового_аккаунта>")
        return

    try:
        main_id = int(args[1])
        new_id = int(args[2])
        new_token = args[3]

        # Подключение к основной базе данных
        with sqlite3.connect('Database/Files/player.sqlite') as db:
            cursor = db.cursor()

            # Получение данных основного аккаунта
            cursor.execute("SELECT Data FROM main WHERE ID = ?", (main_id,))
            main_account = cursor.fetchone()
            if not main_account:
                bot.send_message(message.chat.id, "❌ Основной аккаунт с указанным ID не найден.")
                return

            # Получение данных нового аккаунта
            cursor.execute("SELECT Data FROM main WHERE ID = ?", (new_id,))
            new_account = cursor.fetchone()
            if not new_account:
                bot.send_message(message.chat.id, "❌ Новый аккаунт с указанным ID не найден.")
                return

            # Сохранение ID и токена нового аккаунта в отдельную базу данных
            with sqlite3.connect('Database/Files/users.sqlite') as users_db:
                users_cursor = users_db.cursor()
                users_cursor.execute("CREATE TABLE IF NOT EXISTS accounts (ID INTEGER, Token TEXT)")
                users_cursor.execute("INSERT INTO accounts (ID, Token) VALUES (?, ?)", (new_id, new_token))
                users_db.commit()

            # Удаление нового аккаунта из основной базы
            cursor.execute("DELETE FROM main WHERE ID = ?", (new_id,))
            db.commit()

            # Загрузка данных из основного аккаунта и обновление ID и токена
            main_data = json.loads(main_account[0])
            main_data["ID"] = [main_data["ID"][0], new_id]
            main_data["Token"] = new_token

            # Обновление данных основного аккаунта в базе данных
            cursor.execute(
                """
                UPDATE main 
                SET Data = ?, ID = ?, Token = ? 
                WHERE ID = ?
                """,
                (json.dumps(main_data, ensure_ascii=False), new_id, new_token, main_id)
            )

            db.commit()

            bot.send_message(
                message.chat.id,
                f"✅ Аккаунт успешно восстановлен!\n"
                f"🆔 Новый ID: {new_id}\n🔑 Новый токен: {new_token}\n"
            )

    except ValueError:
        bot.send_message(message.chat.id, "❌ ID должны быть числами.")
    except Exception as e:
        logging.error(f"Ошибка в команде /recovery: {e}")
        bot.send_message(message.chat.id, f"❌ Произошла ошибка: {str(e)}")

bot.polling()