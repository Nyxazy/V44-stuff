from Classes.ByteStream import ByteStream
from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
import Configuration


class SeasonRewardsMessage(PiranhaMessage):

    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def encode(self, fields, player):
    	self.writeVInt(fields["Type"]) # Type
    	if fields["Type"] == 6:
    		self.writeVInt(len(Configuration.settings["ChallengeRewards"])) # Count
    		for x in Configuration.settings["ChallengeRewards"]:
    			self.writeVInt(x["Win"]) # Win
    			self.writeVInt(0) # ?
    			self.writeVInt(0) # ?
    			self.writeBoolean(True) # Reward
    			self.writeVInt(x["Type"]) # RewardType
    			self.writeVInt(x["Amount"]) # RewardCount
    			self.writeDataReference(x["Brawler"][0], x["Brawler"][1]) # Brawler
    			self.writeVInt(x["Extra"]) # Extra
    			self.writeBoolean(False) # Reward
    		self.writeBoolean(True) # FinalReward?
    		for x in range(1):
    		  	self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Type"])
    		  	self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Amount"])
    		  	self.writeDataReference(Configuration.settings["ChallengeFinalReward"]["Brawler"][0], Configuration.settings["ChallengeFinalReward"]["Brawler"][1])
    		  	self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Extra"])
    	else:
    		self.writeVInt(0) # Count


    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24123

    def getMessageVersion(self):
        return self.messageVersion
