from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import TeamDatabaseHandler, DatabaseHandler
import json


class TeamGameStartingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        teamdb_instance = TeamDatabaseHandler()
        db_instance = DatabaseHandler()
        teamData = json.loads(teamdb_instance.getTeamWithLowID(player.TeamID[1])[0][1])
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)


    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24130

    def getMessageVersion(self):
        return self.messageVersion