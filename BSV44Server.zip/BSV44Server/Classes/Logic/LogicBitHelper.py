class LogicBitHelper:
    @staticmethod
    def get(value, index):
        if value is None:
            value = 0
        return ((value >> index) & 1) == 1

    @staticmethod
    def set(value, index, data):
        if value is None:
            value = 0
        value &= ~(1 << index)
        if data:
            value |= (1 << index)
        return value
