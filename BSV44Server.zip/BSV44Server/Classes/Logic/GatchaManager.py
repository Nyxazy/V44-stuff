import random
from Classes.Files.DataTables import DataTables, DataType

UNLOCKABLE_HEROES_COUNT = 38

class GatchaManager:
    @staticmethod
    def simulate_gatcha(player_data, unit_type):
        """
        Implements a 100% exact port of HomeMode.SimulateGatcha() from C# used as the source of truth,
        powered by the dynamic DataTables CSV system.
        """
        # Load tables
        DataTables.load()
        
        # Increment RollsSinceGoodDrop (pity counter)
        player_data["RollsSinceGoodDrop"] = player_data.get("RollsSinceGoodDrop", 0) + 1
        
        drops = []
        is_brawler = False
        
        # 1. Brawler unlock probability & pity counters
        unlocked_count = len(player_data.get("OwnedBrawlers", {}))
        brawler_chance = 10 if unit_type == 10 else 20
        if unlocked_count < 4:
            brawler_chance = 70
        elif unlocked_count < 6:
            brawler_chance = 40
            
        if random.randint(0, 100) < brawler_chance:
            # GetRandomBrawlerForGatcha
            attempts = 0
            while attempts < 25:
                attempts += 1
                brawler_id = random.randint(0, UNLOCKABLE_HEROES_COUNT - 1)
                
                # Fetch character data via dynamic DataTables
                char_data = DataTables.get(DataType.Character).get_data_by_id(16000000 + brawler_id)
                if not char_data or char_data.get("Disabled"):
                    continue
                    
                char_name = char_data["Name"]
                has_hero = str(brawler_id) in player_data.get("OwnedBrawlers", {})
                if not has_hero:
                    # Get unlock card details dynamically
                    rarity, card_name = "common", ""
                    card_table = DataTables.get(DataType.Card)
                    for card in card_table.get_datas():
                        if card.get("Target", "").lower() == char_name.lower() and card.get("Type", "").lower() == "unlock":
                            rarity = card.get("Rarity", "common").lower()
                            card_name = card.get("Name")
                            break
                    
                    # C# condition: done = card.Rarity != "common" && card.Name != "Blower_unlock";
                    if rarity != "common" and card_name != "Blower_unlock":
                        done = False
                        
                        # Epic pity
                        if rarity == "epic":
                            if player_data["RollsSinceGoodDrop"] > 6:
                                player_data["RollsSinceGoodDrop"] = 0
                                done = True
                            else:
                                done = player_data["RollsSinceGoodDrop"] > random.randint(0, 1000)
                                if done:
                                    player_data["RollsSinceGoodDrop"] = 0
                                    
                        # Mythic pity ("mega_epic" in V44 csv)
                        elif rarity == "mega_epic":
                            if player_data["RollsSinceGoodDrop"] > 25:
                                player_data["RollsSinceGoodDrop"] = 0
                                done = True
                            else:
                                done = player_data["RollsSinceGoodDrop"] > random.randint(0, 1000)
                                if done:
                                    player_data["RollsSinceGoodDrop"] = 0
                                    
                        # Legendary pity
                        elif rarity == "legendary":
                            if player_data["RollsSinceGoodDrop"] > 100:
                                player_data["RollsSinceGoodDrop"] = 0
                                done = True
                            else:
                                done = player_data["RollsSinceGoodDrop"] > random.randint(0, 1000)
                                if done:
                                    player_data["RollsSinceGoodDrop"] = 0
                        else:
                            # Rare and Super Rare have no pity restrictions, they unlock directly
                            done = True
                            
                        if done:
                            # Unlock the brawler
                            player_data["OwnedBrawlers"][str(brawler_id)] = {
                                'CardID': brawler_id * 1000000 + 23, # ClassCard = 23
                                'Skins': [],
                                'Trophies': 0,
                                'HighestTrophies': 0,
                                'PowerLevel': 1,
                                'PowerPoints': 0,
                                'State': 1
                            }
                            drops.append({
                                'Amount': 1, 
                                'DataRef': [16, brawler_id], 
                                'RewardID': 1 # Unlock Hero
                            })
                            is_brawler = True
                            break
                            
        # 2. Reward Ranges (Coins and Power Points)
        # In C#, if a brawler was unlocked, coins and powerpoints are NOT generated for Brawl Box (Type 10)!
        # "if (!isBrawler)" holds the coin/powerpoint generation logic for unit.Type == 10!
        if not (unit_type == 10 and is_brawler):
            # Coins Distribution
            coins_amount = 0
            if unit_type == 10:
                coins_amount = random.randint(15, 40)
            elif unit_type == 11:
                coins_amount = random.randint(322, 600)
            elif unit_type == 12:
                coins_amount = random.randint(60, 250)
            
            if coins_amount > 0:
                drops.append({
                    'Amount': coins_amount, 
                    'DataRef': [0, 0], 
                    'RewardID': 7
                })
                player_data["Coins"] = player_data.get("Coins", 0) + coins_amount

            # Power Point Distribution Logic
            owned_brawlers = list(player_data.get("OwnedBrawlers", {}).keys())
            pp_count = 2 if unit_type == 10 else (5 if unit_type == 11 else 3)
            generated_pp_brawlers = []
            
            for _ in range(pp_count):
                if not owned_brawlers:
                    break
                brawler_id = random.choice(owned_brawlers)
                if brawler_id in generated_pp_brawlers:
                    continue
                
                brawler_info = player_data["OwnedBrawlers"][brawler_id]
                current_pp = brawler_info.get("PowerPoints", 0)
                needed_pp = 1410 - current_pp
                if needed_pp > 0:
                    if unit_type == 10:
                        pp_drop = random.randint(5, 25)
                    elif unit_type == 11:
                        pp_drop = random.randint(40, 80)
                    else:
                        pp_drop = random.randint(10, 50)
                    
                    pp_drop = min(pp_drop, needed_pp)
                    drops.append({
                        'Amount': pp_drop, 
                        'DataRef': [16, int(brawler_id)], 
                        'RewardID': 6
                    })
                    brawler_info["PowerPoints"] += pp_drop
                    generated_pp_brawlers.append(brawler_id)

        # 3. Gem Distribution Logic (Gems bonus)
        if random.randint(0, 100) < 50:
            gems_amount = random.randint(2, 7) + 1
            drops.append({
                'Amount': gems_amount, 
                'DataRef': [0, 0], 
                'RewardID': 8
            })
            player_data["Gems"] = player_data.get("Gems", 0) + gems_amount
            
        return drops
