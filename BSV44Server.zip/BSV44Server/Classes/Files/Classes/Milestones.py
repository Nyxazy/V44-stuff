import csv
import os

class Milestones:
    _milestones = {}
    _loaded = False

    @classmethod
    def load(cls):
        if cls._loaded:
            return
        
        path = 'Classes/Files/assets/csv_logic/milestones.csv'
        if not os.path.exists(path):
            # Fallback for workspace directory structure
            path = '/home/user/extracted/BSV44Server/Classes/Files/assets/csv_logic/milestones.csv'

        with open(path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            header = next(reader)
            types = next(reader)
            
            for row in reader:
                if not row or not row[0]:
                    continue
                name = row[0]
                
                def get_int(val, default=0):
                    if not val:
                        return default
                    try:
                        return int(val)
                    except ValueError:
                        return default

                cls._milestones[name] = {
                    "Name": name,
                    "Type": get_int(row[1]),
                    "Index": get_int(row[2]),
                    "ProgressStart": get_int(row[3]),
                    "Progress": get_int(row[4]),
                    "League": get_int(row[5]),
                    "Tier": get_int(row[6]),
                    "Season": get_int(row[7]),
                    "PrimaryLvlUpRewardType": get_int(row[9], -1),
                    "PrimaryLvlUpRewardCount": get_int(row[10], 0),
                    "PrimaryLvlUpRewardExtraData": get_int(row[11], 0),
                    "PrimaryLvlUpRewardData": row[12],
                    "SecondaryLvlUpRewardType": get_int(row[13], -1),
                    "SecondaryLvlUpRewardCount": get_int(row[14], 0),
                    "SecondaryLvlUpRewardExtraData": get_int(row[15], 0),
                    "SecondaryLvlUpRewardData": row[16],
                }
        cls._loaded = True

    @classmethod
    def get_by_name(cls, name):
        cls.load()
        return cls._milestones.get(name)
