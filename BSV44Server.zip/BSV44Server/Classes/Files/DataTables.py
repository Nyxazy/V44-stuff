import csv
import os

class DataType:
    Projectile = 6
    AllianceBadge = 8
    Location = 15
    Character = 16
    AreaEffect = 17
    Item = 18
    Map = 19
    Skill = 20
    Card = 23
    Tile = 27
    PlayerThumbnail = 28
    Skin = 29
    Milestone = 39
    NameColor = 43
    SkinConf = 44
    Accessory = 50
    Emote = 52
    Gear = 62
    Titul = 76
    Mastery = 75
    MasteryVanity = 74
    Spray = 68


class DataTable:
    def __init__(self, datatype, filepath):
        self.datatype = datatype
        self.filepath = filepath
        self.datas = []
        self.datas_by_name = {}
        self.datas_by_id = {}
        self.load()

    def load(self):
        if not os.path.exists(self.filepath):
            # Fallback path if working dir differs
            alt_path = os.path.join('/home/user/extracted/BSV44Server', self.filepath)
            if os.path.exists(alt_path):
                self.filepath = alt_path
            else:
                return

        with open(self.filepath, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            try:
                headers = next(reader)
                types = next(reader)
            except StopIteration:
                return

            row_idx = 0
            for row in reader:
                if not row or not row[0]:
                    continue
                
                # Replicate LogicData base row structure
                name = row[0]
                
                # Create item dictionary mapping exact column names to their typed values
                data_item = {"Name": name, "Index": row_idx}
                
                for idx, col_name in enumerate(headers):
                    if idx < len(row):
                        val = row[idx]
                        col_type = types[idx] if idx < len(types) else "string"
                        
                        # Typed resolution like C# LoadData
                        if col_type == "int":
                            try:
                                data_item[col_name] = int(val) if val else 0
                            except ValueError:
                                data_item[col_name] = 0
                        elif col_type == "boolean":
                            data_item[col_name] = val.lower() == "true"
                        else:
                            data_item[col_name] = val
                
                # Map global ID creation
                global_id = self.datatype * 1000000 + row_idx
                data_item["GlobalId"] = global_id
                
                self.datas.append(data_item)
                self.datas_by_name[name.lower()] = data_item
                self.datas_by_id[global_id] = data_item
                row_idx += 1

    def get_data(self, name):
        if isinstance(name, str):
            return self.datas_by_name.get(name.lower())
        return None

    def get_data_by_id(self, global_id):
        return self.datas_by_id.get(global_id)

    def get_datas(self):
        return self.datas


class DataTables:
    _tables = {}
    _files = {
        DataType.Projectile: "Classes/Files/assets/csv_logic/projectiles.csv",
        DataType.AllianceBadge: "Classes/Files/assets/csv_logic/alliance_badges.csv",
        DataType.Location: "Classes/Files/assets/csv_logic/locations.csv",
        DataType.Character: "Classes/Files/assets/csv_logic/characters.csv",
        DataType.AreaEffect: "Classes/Files/assets/csv_logic/area_effects.csv",
        DataType.Item: "Classes/Files/assets/csv_logic/items.csv",
        DataType.Map: "Classes/Files/assets/csv_logic/maps.csv",
        DataType.Skill: "Classes/Files/assets/csv_logic/skills.csv",
        DataType.Card: "Classes/Files/assets/csv_logic/cards.csv",
        DataType.Tile: "Classes/Files/assets/csv_logic/tiles.csv",
        DataType.PlayerThumbnail: "Classes/Files/assets/csv_logic/player_thumbnails.csv",
        DataType.Skin: "Classes/Files/assets/csv_logic/skins.csv",
        DataType.Milestone: "Classes/Files/assets/csv_logic/milestones.csv",
        DataType.SkinConf: "Classes/Files/assets/csv_logic/skin_confs.csv",
        DataType.Accessory: "Classes/Files/assets/csv_logic/accessories.csv",
        DataType.Emote: "Classes/Files/assets/csv_logic/emotes.csv",
        DataType.Gear: "Classes/Files/assets/csv_logic/gear_boosts.csv",
        DataType.NameColor: "Classes/Files/assets/csv_logic/name_colors.csv",
        DataType.Titul: "Classes/Files/assets/csv_logic/player_titles.csv",
    }

    @classmethod
    def load(cls):
        if cls._tables:
            return
        for datatype, filepath in cls._files.items():
            cls._tables[datatype] = DataTable(datatype, filepath)

    @classmethod
    def get(cls, datatype):
        cls.load()
        return cls._tables.get(datatype)
