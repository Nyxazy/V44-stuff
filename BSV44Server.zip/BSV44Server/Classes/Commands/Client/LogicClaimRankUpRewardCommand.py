import json
import random
from Classes.ByteStream import ByteStream
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Logic.LogicBitHelper import LogicBitHelper
from Classes.Files.DataTables import DataTables, DataType
from Classes.Logic.GatchaManager import GatchaManager


class LogicClaimRankUpRewardCommand(LogicCommand):
    
    def __init__(self, commandData):
        super().__init__(commandData)

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["MilestoneID"] = calling_instance.readVInt()
        
        # ReadDataReference
        class_id = calling_instance.readVInt()
        if class_id > 0:
            instance_id = calling_instance.readVInt()
            fields["UnknownDataId"] = class_id * 1000000 + instance_id
        else:
            fields["UnknownDataId"] = 0
            
        fields["Unk"] = calling_instance.readVInt()
        fields["LVL"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def encode(self, fields):
    	pass

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        milestone_id = fields["MilestoneID"]
        required_milestone = fields["LVL"]
        unknown_data_id = fields["UnknownDataId"]
        
        # Ensure dynamic progression variables are initialized
        if "TrophyRoadProgress" not in player_data:
            player_data["TrophyRoadProgress"] = player_data.get("TrophyRoadTier", 1)
            if player_data["TrophyRoadProgress"] == 99999 or player_data["TrophyRoadProgress"] > 10000:
                player_data["TrophyRoadProgress"] = 1
                
        player_data.setdefault("BrawlPassProgress", 1)
        player_data.setdefault("PremiumPassProgress", 1)
        player_data.setdefault("BrawlPassPlusProgress", 1)
        player_data["BrawlPassTokens"] = player_data.get("BrawlPassTokens", player_data.get("BPTokens", 0))
        player_data["HasPremiumPass"] = player_data.get("HasPremiumPass", player_data.get("BPActivated", False))

        if milestone_id == 6:
            # Trophy Road claiming
            name = f"goal_6_{player_data['TrophyRoadProgress'] - 1}"
            milestone_data = DataTables.get(DataType.Milestone).get_data(name)
            if not milestone_data:
                print(f"[LogicClaimRankUpRewardCommand] Milestone null: {name}")
                return
                
            required_progress = milestone_data["Progress"] + milestone_data["ProgressStart"]
            if player_data.get("HighestTrophies", 0) < required_progress:
                print(f"[LogicClaimRankUpRewardCommand] Insufficient HighestTrophies: {player_data.get('HighestTrophies', 0)} < {required_progress}")
                return
                
            # Process reward
            if self.process_reward(player_data, milestone_data, False, 6, player_data["TrophyRoadProgress"] + 1, 0, calling_instance) != 0:
                return
                
            player_data["TrophyRoadProgress"] += 1
            player_data["TrophyRoadTier"] = player_data["TrophyRoadProgress"]
            
        elif milestone_id in (9, 10, 12):
            # Brawl Pass claiming
            name = f"Goal_{milestone_id}_22_{required_milestone}"
            if milestone_id == 9 and not player_data["HasPremiumPass"]:
                print(f"[LogicClaimRankUpRewardCommand] No premium pass")
                return
                
            milestone_data = DataTables.get(DataType.Milestone).get_data(name)
            if not milestone_data:
                print(f"[LogicClaimRankUpRewardCommand] Milestone null: {name}")
                return
                
            required_progress = milestone_data["Progress"] + milestone_data["ProgressStart"]
            if player_data["BrawlPassTokens"] < required_progress:
                print(f"[LogicClaimRankUpRewardCommand] Insufficient tokens: {player_data['BrawlPassTokens']} < {required_progress}")
                return
                
            # Check already claimed bits via LogicBitHelper
            claimed = False
            if milestone_id == 9:
                claimed = LogicBitHelper.get(player_data["PremiumPassProgress"], required_milestone + 2)
            elif milestone_id == 10:
                claimed = LogicBitHelper.get(player_data["BrawlPassProgress"], required_milestone + 2)
            elif milestone_id == 12:
                claimed = LogicBitHelper.get(player_data["BrawlPassPlusProgress"], required_milestone + 2)
                
            if claimed:
                print(f"[LogicClaimRankUpRewardCommand] Milestone already claimed: {required_milestone}")
                return
                
            # Process reward
            if self.process_reward(player_data, milestone_data, False, milestone_id, required_milestone + 2, 22, calling_instance) != 0:
                return
                
            # Set claimed bits
            if milestone_id == 9:
                player_data["PremiumPassProgress"] = LogicBitHelper.set(player_data["PremiumPassProgress"], required_milestone + 2, True)
            elif milestone_id == 10:
                player_data["BrawlPassProgress"] = LogicBitHelper.set(player_data["BrawlPassProgress"], required_milestone + 2, True)
            elif milestone_id == 12:
                player_data["BrawlPassPlusProgress"] = LogicBitHelper.set(player_data["BrawlPassPlusProgress"], required_milestone + 2, True)
                
        else:
            print(f"[LogicClaimRankUpRewardCommand] Unknown milestone ID: {milestone_id}")
            return
            
        # Update database and notify client
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields)

    def process_reward(self, player_data, milestone_data, use_secondary, track, idx, bp_season, calling_instance):
        reward_type = milestone_data["SecondaryLvlUpRewardType"] if use_secondary else milestone_data["PrimaryLvlUpRewardType"]
        reward_data = milestone_data["SecondaryLvlUpRewardData"] if use_secondary else milestone_data["PrimaryLvlUpRewardData"]
        reward_count = milestone_data["SecondaryLvlUpRewardCount"] if use_secondary else milestone_data["PrimaryLvlUpRewardCount"]
        
        print(f"[LogicClaimRankUpRewardCommand] ProcessReward: type={reward_type}, data={reward_data}, count={reward_count}")
        
        box = None
        
        if reward_type == 1:
            # Coins
            player_data["Coins"] = player_data.get("Coins", 0) + reward_count
            item = {'Amount': reward_count, 'DataRef': [0, 0], 'RewardID': 7}
            box = {'Type': 100, 'Items': [item]}
            
        elif reward_type == 3:
            # Character Unlock
            char_data = DataTables.get(DataType.Character).get_data(reward_data)
            if char_data:
                char_id = char_data["Index"]
                if str(char_id) in player_data["OwnedBrawlers"]:
                    return self.process_reward(player_data, milestone_data, True, track, idx, bp_season, calling_instance)
                
                # Unlock Hero
                player_data["OwnedBrawlers"][str(char_id)] = {
                    'CardID': char_id * 1000000 + 23, # ClassCard = 23
                    'Skins': [],
                    'Trophies': 0,
                    'HighestTrophies': 0,
                    'PowerLevel': 1,
                    'PowerPoints': 0,
                    'State': 1
                }
                item = {'Amount': 1, 'DataRef': [16, char_id], 'RewardID': 1}
                box = {'Type': 100, 'Items': [item]}
            else:
                return self.process_reward(player_data, milestone_data, True, track, idx, bp_season, calling_instance)
                
        elif reward_type in (6, 9):
            # Brawl Box
            drops = GatchaManager.simulate_gatcha(player_data, 10)
            box = {'Type': 10, 'Items': drops}
            
        elif reward_type == 10:
            # Big Box
            drops = GatchaManager.simulate_gatcha(player_data, 12)
            box = {'Type': 12, 'Items': drops}
            
        elif reward_type == 14:
            # Mega Box
            drops = GatchaManager.simulate_gatcha(player_data, 11)
            box = {'Type': 11, 'Items': drops}
            
        elif reward_type == 12:
            # Specific Brawler Power Points
            char_data = DataTables.get(DataType.Character).get_data(reward_data)
            char_id = char_data["Index"] if char_data else -1
            
            if char_id != -1 and str(char_id) in player_data["OwnedBrawlers"]:
                player_data["OwnedBrawlers"][str(char_id)]["PowerPoints"] = player_data["OwnedBrawlers"][str(char_id)].get("PowerPoints", 0) + reward_count
                item = {'Amount': reward_count, 'DataRef': [16, char_id], 'RewardID': 6}
                box = {'Type': 100, 'Items': [item]}
            else:
                return self.process_reward(player_data, milestone_data, True, track, idx, bp_season, calling_instance)
                
        elif reward_type == 4:
            # Skin
            skin_data = DataTables.get(DataType.Skin).get_data(reward_data)
            if skin_data:
                skin_id = skin_data["Index"]
                self.unlock_skin_dynamic(player_data, skin_id)
                item = {'Amount': 1, 'DataRef': [29, skin_id], 'RewardID': 9}
                box = {'Type': 100, 'Items': [item]}
                
        elif reward_type == 16:
            # Gems (Diamonds)
            player_data["Gems"] = player_data.get("Gems", 0) + reward_count
            item = {'Amount': reward_count, 'DataRef': [0, 0], 'RewardID': 8}
            box = {'Type': 100, 'Items': [item]}
            
        elif reward_type == 19:
            # Emote
            emote_data = DataTables.get(DataType.Emote).get_data(reward_data)
            if emote_data:
                emote_id = emote_data["Index"]
                if emote_id not in player_data.get("OwnedPins", []):
                    player_data.setdefault("OwnedPins", []).append(emote_id)
                item = {'Amount': 1, 'DataRef': [52, emote_id], 'RewardID': 11}
                box = {'Type': 100, 'Items': [item]}
                
        elif reward_type == 25:
            # Thumbnail
            thumb_data = DataTables.get(DataType.PlayerThumbnail).get_data(reward_data)
            if thumb_data:
                thumb_id = thumb_data["Index"]
                if thumb_id not in player_data.get("OwnedThumbnails", []):
                    player_data.setdefault("OwnedThumbnails", []).append(thumb_id)
                item = {'Amount': 1, 'DataRef': [28, thumb_id], 'RewardID': 11}
                box = {'Type': 100, 'Items': [item]}
                
        elif reward_type == 38:
            # Rare tokens (Star points)
            player_data["StarPoints"] = player_data.get("StarPoints", 0) + reward_count
            item = {'Amount': reward_count, 'DataRef': [0, 0], 'RewardID': 22}
            box = {'Type': 100, 'Items': [item]}
            
        elif reward_type == 41:
            # Wildcard power points (Wildcard PPT)
            player_data["StarPoints"] = player_data.get("StarPoints", 0) + reward_count # fallback StarPoints
            item = {'Amount': reward_count, 'DataRef': [0, 0], 'RewardID': 24}
            box = {'Type': 100, 'Items': [item]}
            
        elif reward_type == 45:
            # Blings
            player_data["Coins"] = player_data.get("Coins", 0) + reward_count # fallback Coins
            item = {'Amount': reward_count, 'DataRef': [0, 0], 'RewardID': 25}
            box = {'Type': 100, 'Items': [item]}
            
        elif reward_type == 50:
            # Starr Drop (Gems fallback)
            player_data["Gems"] = player_data.get("Gems", 0) + reward_count
            item = {'Amount': reward_count, 'DataRef': [0, 0], 'RewardID': 8}
            box = {'Type': 100, 'Items': [item]}
            
        else:
            print(f"[LogicClaimRankUpRewardCommand] Unsupported reward type: {reward_type}")
            return -1
            
        if box:
            player_data.setdefault("delivery_items", {})["Boxes"] = [box]
            
        return 0

    def unlock_skin_dynamic(self, player_data, skin_id):
        skin_data = DataTables.get(DataType.Skin).get_data_by_id(DataType.Skin * 1000000 + skin_id)
        if not skin_data:
            return
        skin_conf_name = skin_data["Conf"]
        skin_conf_data = DataTables.get(DataType.SkinConf).get_data(skin_conf_name)
        if not skin_conf_data:
            return
        char_name = skin_conf_data["Character"]
        char_data = DataTables.get(DataType.Character).get_data(char_name)
        if not char_data:
            return
        char_id = char_data["Index"]
        
        char_key = str(char_id)
        if char_key in player_data["OwnedBrawlers"]:
            player_data["OwnedBrawlers"][char_key].setdefault("Skins", [])
            if skin_id not in player_data["OwnedBrawlers"][char_key]["Skins"]:
                player_data["OwnedBrawlers"][char_key]["Skins"].append(skin_id)

    def getCommandType(self):
        return 517
