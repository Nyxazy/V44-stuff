import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
from Classes.Files.Classes.Cards import Cards
from Classes.Files.Classes.Characters import Characters
from Classes.Logic.GatchaManager import GatchaManager


class LogicGatchaCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["box_id"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        box_id = fields["box_id"]
        gem_cost = 0
        unit_type = 10
        
        if box_id == 1: # Big Box
            gem_cost = 30
            unit_type = 12
        elif box_id == 3: # Mega Box
            gem_cost = 80
            unit_type = 11
            
        if player_data.get("Gems", 0) < gem_cost:
            print(f"[LogicGatchaCommand] Insufficient gems: {player_data.get('Gems', 0)} < {gem_cost}")
            return
            
        player_data["Gems"] -= gem_cost
        
        # Simulate gacha using the unified C#-matching GatchaManager
        drops = GatchaManager.simulate_gatcha(player_data, unit_type)
        
        box = {
            'Type': unit_type,
            'Items': drops
        }
        
        player_data.setdefault("delivery_items", {})["Boxes"] = [box]
        
        db_instance.updatePlayerData(player_data, calling_instance)
        
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields)

    def getCommandType(self):
        return 500
