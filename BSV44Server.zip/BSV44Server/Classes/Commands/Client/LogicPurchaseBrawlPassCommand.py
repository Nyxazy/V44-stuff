import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import Configuration


class LogicPurchaseBrawlPassCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["BPSeason"] = calling_instance.readVInt()
        fields["Unk"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        # C# behavior: use 169 gems
        if player_data.get("Gems", 0) >= 169:
            player_data["Gems"] -= 169
            player_data["BPActivated"] = True
            player_data["HasPremiumPass"] = True
            
            try:
                player_data["Notifications"]
            except KeyError:
                player_data["Notifications"] = []
                
            notification = {
                "Type": 71, 
                "Readed": False, 
                "Timer": 0, 
                "Text": "Thanks for purchasing BrawlPass", 
                "BPSeason": Configuration.settings["CurrentBPSeason"], 
                "Tokens": 5000, 
                "Number": len(player_data["Notifications"]) + 1
            }
            player_data["Notifications"].append(notification)
            
            # Add some tokens as extra bonus (matches V44 reference python server)
            player_data["BrawlPassTokens"] = player_data.get("BrawlPassTokens", 0) + 5000
            player_data["BPTokens"] = player_data.get("BPTokens", 0) + 5000
            
            db_instance.updatePlayerData(player_data, calling_instance)
            fields["Notification"] = notification
            fields["Socket"] = calling_instance.client
            fields["Command"] = {"ID": 206}
            Messaging.sendMessage(24111, fields)

    def getCommandType(self):
        return 534
